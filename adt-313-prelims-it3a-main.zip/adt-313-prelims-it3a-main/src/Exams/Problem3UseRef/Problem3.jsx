import React, { useRef } from 'react';

function Problem3() {
  const inputRefs = useRef(Array.from({ length: 10 }, () => React.createRef()));

  const focusFirstEmptyInput = () => {
    for (let ref of inputRefs.current) {
      if (ref.current && ref.current.value === '') {
        ref.current.focus();
        break;
      }
    }
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Input 1: <input type='text' ref={inputRefs.current[0]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 2: <input type='text' ref={inputRefs.current[1]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 3: <input type='text' ref={inputRefs.current[2]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 4: <input type='text' ref={inputRefs.current[3]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 5: <input type='text' ref={inputRefs.current[4]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 6: <input type='text' ref={inputRefs.current[5]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 7: <input type='text' ref={inputRefs.current[6]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 8: <input type='text' ref={inputRefs.current[7]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 9: <input type='text' ref={inputRefs.current[8]} />
      </div>
      <div style={{ display: 'block' }}>
        Input 10: <input type='text' ref={inputRefs.current[9]} />
      </div>
      <button type='button' onClick={focusFirstEmptyInput}>I'm a button</button>
    </>
  );
}

export default Problem3;
