import React, { useState } from 'react';

function Problem2() {

  const user = {
    name: "Mark James Rogelio",
    course: "BS Information Technology",
    section: "ADT313",
    imageUrl: 'https://i.imgur.com/yXOvdOSs.jpg',
    imageSize: 90,
  };

  const Profile = () => {
    return (
      <div className="profile-container">
        <div>{user.name}</div>
        <div>{user.section}</div>
        <div>{user.course}</div>
        <img
          className="avatar"
          src={user.imageUrl}
          alt="Profile photo"
          style={{
            width: user.imageSize,
            height: user.imageSize,
            borderRadius: '50%', 
            objectFit: 'cover',
          }}
        />
      </div>
    );
  };

  const InitialContent = () => {
    return <h1>User profile is hidden.</h1>;
  };

  const [isProfileVisible, setIsProfileVisible] = useState(false);

  const toggleProfile = () => {
    setIsProfileVisible((prevVisible) => !prevVisible);
  };

  return (
    <div className="problem2-container">
      {isProfileVisible ? <Profile /> : <InitialContent />}
      <button 
        type="button" 
        onClick={toggleProfile}
        className="toggle-button"
      >
        {isProfileVisible ? 'Hide Profile' : 'Show Profile'}
      </button>
    </div>
  );
}

export default Problem2;