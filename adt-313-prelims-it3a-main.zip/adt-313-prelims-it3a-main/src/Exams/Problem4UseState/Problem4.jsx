import React, { useState } from 'react';

export default function Problem4() {
  const [formData, setFormData] = useState({
    name: "Mark James Rogelio",
    yearLevel: "",
    course: "BSIT",
  });

  const handleNameChange = (event) => {
    setFormData({ ...formData, name: event.target.value });
  };


  const handleYearLevelChange = (event) => {
    setFormData({ ...formData, yearLevel: event.target.value });
  };


  const handleCourseChange = (event) => {
    setFormData({ ...formData, course: event.target.value });
  };

  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' value={formData.name} onChange={handleNameChange} />
      </div>
      <div style={{ display: 'block' }}>
        <p>Year Level:</p>
        <input
          type='radio'
          id='firstYear'
          name='yearlevel'
          value='First Year'
          checked={formData.yearLevel === 'First Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor='firstYear'>First Year</label>
        <br />
        
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year'
          checked={formData.yearLevel === 'Second Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor='secondYear'>Second Year</label>
        <br />
        
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year'
          checked={formData.yearLevel === 'Third Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor='thirdYear'>Third Year</label>
        <br />
        
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year'
          checked={formData.yearLevel === 'Fourth Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor='fourthYear'>Fourth Year</label>
        <br />
        
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fifth Year'
          checked={formData.yearLevel === 'Fifth Year'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor='fifthYear'>Fifth Year</label>
        <br />
        
        <input
          type='radio'
          id='irregular'
          name='yearlevel'
          value='Irregular'
          checked={formData.yearLevel === 'Irregular'}
          onChange={handleYearLevelChange}
        />
        <label htmlFor='irregular'>Irregular</label>
        <br />
      </div>
      
      <div style={{ display: 'block' }}>
        Course:
        <select value={formData.course} onChange={handleCourseChange}>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>

      
    </>
  );
}
