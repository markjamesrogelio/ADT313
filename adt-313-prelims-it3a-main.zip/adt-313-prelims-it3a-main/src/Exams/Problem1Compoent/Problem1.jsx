import React from 'react';
import StudentName from './StudentName/student';
import Course from './Course/course';
import Section from './Section/section';

const Problem1 = () => {
  const studentData = {
    name: "Mark James Rogelio",
    course: "BS Information Technology",
    section: "ADT313"
  };

  return (
    <div>
      <h3>Student Information</h3>
      <StudentName name={studentData.name} />
      <Course course={studentData.course} />
      <Section section={studentData.section} />
    </div>
  );
};

export default Problem1;
