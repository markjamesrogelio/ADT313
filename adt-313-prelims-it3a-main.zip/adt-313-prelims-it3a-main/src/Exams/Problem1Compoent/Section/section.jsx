import React from 'react';

const Section = ({ section }) => {
  return <p><strong>Section:</strong> {section}</p>;
};

export default Section;
