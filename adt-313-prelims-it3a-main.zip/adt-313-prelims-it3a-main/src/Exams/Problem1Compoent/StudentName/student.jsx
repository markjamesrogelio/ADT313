import React from 'react';

const StudentName = ({ name }) => {
  return <p><strong>Name:</strong> {name}</p>;
};

export default StudentName;
