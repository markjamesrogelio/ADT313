import React from 'react';

const Course = ({ course }) => {
  return <p><strong>Course:</strong> {course}</p>;
};

export default Course;
