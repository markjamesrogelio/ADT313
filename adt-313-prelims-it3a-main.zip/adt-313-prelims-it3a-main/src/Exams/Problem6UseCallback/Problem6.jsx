import { useCallback, useEffect, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selected, setSelected] = useState({
    vin: '',
    make: '',
    model: '',
    year: '',
    color: ''
  });
  const [isEditing, setIsEditing] = useState(false);

  const handleInputChange = useCallback((e) => {
    const { name, value } = e.target;
    setSelected(prev => ({
      ...prev,
      [name]: value
    }));
  }, []);

  const handleEdit = useCallback((car) => {
    setSelected(car);
    setIsEditing(true);
  }, []);

  const handleDelete = useCallback((vin) => {
    setCars(prevCars => prevCars.filter(car => car.vin !== vin));
  }, []);

  const handleSave = useCallback(() => {
    if (!selected.vin || !selected.make || !selected.model || !selected.year || !selected.color) {
      alert('Please fill in all fields');
      return;
    }

    if (cars.some(car => car.vin === selected.vin && !isEditing)) {
      alert('VIN already exists');
      return;
    }

    if (isEditing) {
      handleUpdate();
    } else {
      setCars(prevCars => [...prevCars, selected]);
      handleClear();
    }
  }, [cars, selected, isEditing]);

  const handleUpdate = useCallback(() => {
    setCars(prevCars =>
      prevCars.map(car =>
        car.vin === selected.vin ? selected : car
      )
    );
    setIsEditing(false);
    handleClear();
  }, [selected]);

  const handleClear = useCallback(() => {
    setSelected({
      vin: '',
      make: '',
      model: '',
      year: '',
      color: ''
    });
    setIsEditing(false);
  }, []);

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          VIN:{' '}
          <input
            type='text'
            name="vin"
            value={selected.vin}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Make:{' '}
          <input
            type='text'
            name="make"
            value={selected.make}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Model:{' '}
          <input
            type='text'
            name="model"
            value={selected.model}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Year:{' '}
          <input
            type='text'
            name="year"
            value={selected.year}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Color:{' '}
          <input
            type='text'
            name="color"
            value={selected.color}
            onChange={handleInputChange}
          />
        </div>
        <button type='button' onClick={handleSave}>
          {isEditing ? 'Update' : 'Save'}
        </button>
        <button type='button' onClick={handleClear}>Clear</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => {
              return (
                <tr key={car.vin}>
                  <td>{car.vin}</td>
                  <td>{car.make}</td>
                  <td>{car.model}</td>
                  <td>{car.year}</td>
                  <td>{car.color}</td>
                  <td>
                    <button type='button' onClick={() => handleEdit(car)}>Edit</button>
                    <button type='button' onClick={() => handleDelete(car.vin)}>Delete</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </>
  );
}